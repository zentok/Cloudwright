package com.cloudwright.entity;

import com.cloudwright.Cloudwright;
import com.cloudwright.block.BurnerBlock;
import com.cloudwright.block.PropellerBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.Registries;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Блоки судна (координаты относительно штурвала) и всё, что из них следует: вес, подъём, тяга, центры.
 * Одинаково считается на сервере и на клиенте.
 */
public final class ShipData {
	/** Подъём одной полностью прогретой оболочки. */
	public static final float ENVELOPE_LIFT = 1.0f;
	/** Подъём одного блока эфирита (постоянный). */
	public static final float ETHERITE_LIFT = 6.0f;
	/** Сколько оболочек прогревает одна единица мощности горелки. */
	public static final int ENVELOPES_PER_BURNER = 24;
	public static final int MAX_BLOCKS = 1024;

	public record ShipBlock(BlockPos rel, BlockState state, @Nullable NbtCompound be) {
	}

	public final List<ShipBlock> blocks;
	public final Direction forward;

	public float mass;
	public int envelopes;
	public int etherite;
	public int burnerPower;
	public int vents;
	public float thrust;
	public int gyros;
	public Vec3d centerOfMass = Vec3d.ZERO;
	public Vec3d centerOfLift = Vec3d.ZERO;
	public final List<BlockPos> hull = new ArrayList<>();
	public final List<BlockPos> seats = new ArrayList<>();
	public final List<BlockPos> burners = new ArrayList<>();
	public final List<BlockPos> ventPositions = new ArrayList<>();
	/** Блоки, которые видно снаружи (полностью закрытые со всех сторон не рисуем). */
	public final List<ShipBlock> visible = new ArrayList<>();
	/** Блок по относительной позиции — для столкновений с игроками на палубе. */
	public final java.util.Map<BlockPos, BlockState> byPos = new java.util.HashMap<>();
	private final java.util.Map<BlockState, net.minecraft.util.shape.VoxelShape> shapeCache = new java.util.HashMap<>();
	public int minX, minY, minZ, maxX, maxY, maxZ;

	public ShipData(List<ShipBlock> blocks, Direction forward) {
		this.blocks = blocks;
		this.forward = forward.getAxis().isHorizontal() ? forward : Direction.NORTH;
		recompute();
	}

	public boolean isEmpty() {
		return blocks.isEmpty();
	}

	// ------------------------------------------------------------ свойства блоков

	public static float massOf(BlockState state) {
		Block b = state.getBlock();
		if (b instanceof PropellerBlock p) return p.kind.mass;
		if (state.isOf(Cloudwright.BURNER)) return 2.0f;
		if (state.isOf(Cloudwright.STEAM_VENT)) return 1.0f;
		if (state.isOf(Cloudwright.HELM)) return 0.5f;
		if (state.isOf(Cloudwright.ETHERITE_BLOCK)) return 1.0f;
		if (isEnvelope(state)) return 0.1f;
		BlockSoundGroup g = state.getSoundGroup();
		if (g == BlockSoundGroup.WOOL) return 0.1f;
		if (g == BlockSoundGroup.WOOD || g == BlockSoundGroup.NETHER_WOOD || g == BlockSoundGroup.BAMBOO_WOOD
				|| g == BlockSoundGroup.CHERRY_WOOD || g == BlockSoundGroup.LADDER || g == BlockSoundGroup.SCAFFOLDING) return 0.5f;
		if (g == BlockSoundGroup.GLASS) return 0.3f;
		if (g == BlockSoundGroup.METAL || g == BlockSoundGroup.ANVIL || g == BlockSoundGroup.COPPER
				|| g == BlockSoundGroup.NETHERITE || g == BlockSoundGroup.CHAIN || g == BlockSoundGroup.LANTERN) return 3.0f;
		if (g == BlockSoundGroup.STONE || g == BlockSoundGroup.DEEPSLATE || g == BlockSoundGroup.DEEPSLATE_BRICKS
				|| g == BlockSoundGroup.POLISHED_DEEPSLATE || g == BlockSoundGroup.TUFF || g == BlockSoundGroup.NETHER_BRICKS) return 1.5f;
		return 1.0f;
	}

	public static boolean isEnvelope(BlockState state) {
		return Cloudwright.ENVELOPES.containsValue(state.getBlock());
	}

	// ------------------------------------------------------------ расчёт

	public void recompute() {
		mass = 0;
		envelopes = etherite = burnerPower = vents = gyros = 0;
		thrust = 0;
		hull.clear();
		seats.clear();
		burners.clear();
		ventPositions.clear();
		visible.clear();
		byPos.clear();
		for (ShipBlock b : blocks) byPos.put(b.rel(), b.state());
		double mx = 0, my = 0, mz = 0, lx = 0, ly = 0, lz = 0, liftW = 0;
		minX = minY = minZ = Integer.MAX_VALUE;
		maxX = maxY = maxZ = Integer.MIN_VALUE;
		Set<BlockPos> occupied = new HashSet<>();
		for (ShipBlock b : blocks) occupied.add(b.rel());
		for (ShipBlock b : blocks) {
			BlockPos r = b.rel();
			BlockState s = b.state();
			float m = massOf(s);
			mass += m;
			mx += r.getX() * m;
			my += (r.getY() + 0.5) * m;
			mz += r.getZ() * m;
			float lift = 0;
			if (isEnvelope(s)) {
				envelopes++;
				lift = ENVELOPE_LIFT;
			} else if (s.isOf(Cloudwright.ETHERITE_BLOCK)) {
				etherite++;
				lift = ETHERITE_LIFT;
			}
			if (lift > 0) {
				lx += r.getX() * lift;
				ly += (r.getY() + 0.5) * lift;
				lz += r.getZ() * lift;
				liftW += lift;
			}
			int power = BurnerBlock.heatingPower(s);
			if (power > 0) {
				burnerPower += power;
				burners.add(r);
			}
			if (s.isOf(Cloudwright.STEAM_VENT)) {
				vents++;
				ventPositions.add(r);
			}
			if (s.getBlock() instanceof PropellerBlock p) {
				thrust += p.kind.thrust;
				if (p.kind.gyro) gyros++;
			}
			if (s.isIn(Cloudwright.SHIP_SEATS)) seats.add(r);
			minX = Math.min(minX, r.getX());
			minY = Math.min(minY, r.getY());
			minZ = Math.min(minZ, r.getZ());
			maxX = Math.max(maxX, r.getX());
			maxY = Math.max(maxY, r.getY());
			maxZ = Math.max(maxZ, r.getZ());
			boolean outer = false;
			for (Direction d : Direction.values()) {
				if (!occupied.contains(r.offset(d))) {
					outer = true;
					break;
				}
			}
			boolean seen = false;
			for (Direction d : Direction.values()) {
				BlockState n = byPos.get(r.offset(d));
				if (n == null || !n.isOpaqueFullCube(net.minecraft.world.EmptyBlockView.INSTANCE, BlockPos.ORIGIN)) {
					seen = true;
					break;
				}
			}
			if (seen) visible.add(b);
			if (outer && !s.getCollisionShape(net.minecraft.world.EmptyBlockView.INSTANCE, BlockPos.ORIGIN).isEmpty()) hull.add(r);
		}
		if (blocks.isEmpty()) {
			minX = minY = minZ = maxX = maxY = maxZ = 0;
			return;
		}
		centerOfMass = mass > 0 ? new Vec3d(mx / mass, my / mass, mz / mass) : Vec3d.ZERO;
		centerOfLift = liftW > 0 ? new Vec3d(lx / liftW, ly / liftW, lz / liftW) : centerOfMass;
	}

	/** Форма столкновения блока (уже повёрнутого на 90°-шаг), с кэшем. */
	public net.minecraft.util.shape.VoxelShape collisionShape(BlockState rotated) {
		return shapeCache.computeIfAbsent(rotated, st -> {
			try {
				return st.getCollisionShape(net.minecraft.world.EmptyBlockView.INSTANCE, BlockPos.ORIGIN);
			} catch (Throwable t) {
				return net.minecraft.util.shape.VoxelShapes.fullCube();
			}
		});
	}

	/** Насколько оболочки могут прогреться при текущих горелках (0..1). */
	public float maxHeat() {
		if (envelopes == 0) return 0;
		return Math.min(1f, burnerPower * (float) ENVELOPES_PER_BURNER / envelopes);
	}

	public float liftAt(float heat) {
		return envelopes * ENVELOPE_LIFT * heat + etherite * ETHERITE_LIFT;
	}

	// ------------------------------------------------------------ NBT

	public NbtCompound toNbt() {
		NbtCompound tag = new NbtCompound();
		NbtList list = new NbtList();
		for (ShipBlock b : blocks) {
			NbtCompound e = new NbtCompound();
			e.putIntArray("p", new int[]{b.rel().getX(), b.rel().getY(), b.rel().getZ()});
			e.put("s", NbtHelper.fromBlockState(b.state()));
			if (b.be() != null) e.put("b", b.be());
			list.add(e);
		}
		tag.put("Blocks", list);
		tag.putString("Forward", forward.asString());
		return tag;
	}

	public static ShipData fromNbt(NbtCompound tag) {
		List<ShipBlock> out = new ArrayList<>();
		NbtList list = tag.getList("Blocks", NbtElement.COMPOUND_TYPE);
		for (int i = 0; i < list.size(); i++) {
			NbtCompound e = list.getCompound(i);
			int[] p = e.getIntArray("p");
			if (p.length != 3) continue;
			BlockState s = NbtHelper.toBlockState(Registries.BLOCK.getReadOnlyWrapper(), e.getCompound("s"));
			if (s.isAir()) continue;
			out.add(new ShipBlock(new BlockPos(p[0], p[1], p[2]), s, e.contains("b") ? e.getCompound("b") : null));
		}
		Direction f = Direction.byName(tag.getString("Forward"));
		return new ShipData(out, f == null ? Direction.NORTH : f);
	}
}
