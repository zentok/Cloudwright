package com.cloudwright.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FacingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;

/**
 * Пропеллер. Даёт судну тягу, пока горелки дают пар. Ставится ступицей к опоре, лопасти — наружу.
 * Деревянный — лёгкий и слабый, андезитовый — мощный и тяжёлый, «умный» — гироскоп, держит судно ровно.
 */
public class PropellerBlock extends FacingBlock {
	public enum Kind {
		WOODEN(1.0f, 0.5f, false),
		ANDESITE(2.5f, 1.5f, false),
		SMART(1.5f, 1.0f, true);

		public final float thrust;
		public final float mass;
		public final boolean gyro;

		Kind(float thrust, float mass, boolean gyro) {
			this.thrust = thrust;
			this.mass = mass;
			this.gyro = gyro;
		}
	}

	public final Kind kind;

	public PropellerBlock(Kind kind, Settings settings) {
		super(settings);
		this.kind = kind;
		setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.UP));
	}

	@Override
	protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		return getDefaultState().with(FACING, ctx.getSide());
	}

	@Override
	@SuppressWarnings("deprecation")
	public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return switch (state.get(FACING).getAxis()) {
			case Y -> Block.createCuboidShape(0, 6, 0, 16, 10, 16);
			case X -> Block.createCuboidShape(6, 0, 0, 10, 16, 16);
			default -> Block.createCuboidShape(0, 0, 6, 16, 16, 10);
		};
	}
}
