package com.cloudwright.client;

import com.cloudwright.entity.ShipData;
import com.cloudwright.entity.ShipEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

import java.util.Locale;

/** Приборная панель в левом нижнем углу, пока сидишь на судне. */
public final class ShipHud {
	private ShipHud() {
	}

	public static void render(DrawContext ctx, float tickDelta) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.options.hudHidden || !(mc.player.getVehicle() instanceof ShipEntity ship)) return;
		ShipData data = ship.getData();
		if (data == null) return;
		TextRenderer tr = mc.textRenderer;
		float lift = ship.currentLift();
		float mass = data.mass;
		int liftColor = lift > mass * 1.02f ? 0x7CFC7C : (lift > mass * 0.98f ? 0xFFE066 : 0xFF7766);
		double speed = ship.getVelocity().horizontalLength() * 20.0;
		double vSpeed = ship.getVelocity().y * 20.0;
		int fuelSec = Math.round(ship.getFuel() / 20f);

		String[] keys = {
				"hud.cloudwright.altitude", "hud.cloudwright.lift", "hud.cloudwright.heat",
				"hud.cloudwright.throttle", "hud.cloudwright.fuel", "hud.cloudwright.speed"};
		Text[] lines = {
				Text.translatable(keys[0], String.format(Locale.ROOT, "%.0f", ship.getY()), String.format(Locale.ROOT, "%+.1f", vSpeed)),
				Text.translatable(keys[1], fmt(lift), fmt(mass)),
				Text.translatable(keys[2], Math.round(ship.getHeat() * 100), Math.round(data.maxHeat() * 100)),
				Text.translatable(keys[3], Math.round(ship.getThrottle() * 100)),
				Text.translatable(keys[4], fuelSec / 60, String.format(Locale.ROOT, "%02d", fuelSec % 60)),
				Text.translatable(keys[5], String.format(Locale.ROOT, "%.1f", speed))};
		int[] colors = {0xFFFFFF, liftColor, 0xFFB060, 0xFFFFFF, fuelSec > 30 ? 0xFFFFFF : 0xFF7766, 0xFFFFFF};

		int w = 0;
		for (Text t : lines) w = Math.max(w, tr.getWidth(t));
		int x = 6;
		int h = lines.length * 10 + 6;
		int y = ctx.getScaledWindowHeight() - h - 6;
		ctx.fill(x - 3, y - 3, x + w + 3, y + h - 3, 0x88000000);
		for (int i = 0; i < lines.length; i++) {
			ctx.drawTextWithShadow(tr, lines[i], x, y + i * 10, colors[i]);
		}
		if (ship.isVenting()) {
			ctx.drawTextWithShadow(tr, Text.translatable("hud.cloudwright.venting"), x + w + 8, y + 2 * 10, 0xC0E0FF);
		}
	}

	private static String fmt(float v) {
		return String.format(Locale.ROOT, "%.1f", v);
	}
}
