package com.cloudwright.mixin;

import com.cloudwright.entity.ShipCollisions;
import net.minecraft.entity.Entity;
import net.minecraft.util.shape.VoxelShape;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.List;

/** Блоки летящих судов — твёрдые: по палубе можно ходить, о борт можно удариться. */
@Mixin(Entity.class)
public abstract class EntityMixin {
	@ModifyVariable(method = "adjustMovementForCollisions(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;",
			at = @At("STORE"), ordinal = 0)
	private List<VoxelShape> cloudwright$addShipCollisions(List<VoxelShape> list) {
		return ShipCollisions.addShipShapes((Entity) (Object) this, list);
	}
}
