package com.cloudwright.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;

/** Паровое сопло: в полёте по кнопке «Снижение» сбрасывает горячий воздух — судно опускается быстрее. */
public class SteamVentBlock extends Block {
	private static final VoxelShape SHAPE = VoxelShapes.union(
			Block.createCuboidShape(2, 0, 2, 14, 6, 14),
			Block.createCuboidShape(5, 6, 5, 11, 14, 11),
			Block.createCuboidShape(4, 14, 4, 12, 16, 12));

	public SteamVentBlock(Settings settings) {
		super(settings);
	}

	@Override
	@SuppressWarnings("deprecation")
	public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return SHAPE;
	}
}
