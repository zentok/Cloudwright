package com.cloudwright.net;

import com.cloudwright.Cloudwright;
import com.cloudwright.entity.ShipAssembler;
import com.cloudwright.entity.ShipEntity;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.util.Identifier;

/** Пакеты клиент → сервер: ввод пилота и команда «пришвартоваться». */
public final class CloudwrightNetworking {
	public static final Identifier INPUT = Cloudwright.id("input");
	public static final Identifier DOCK = Cloudwright.id("dock");

	private CloudwrightNetworking() {
	}

	public static void registerServer() {
		ServerPlayNetworking.registerGlobalReceiver(INPUT, (server, player, handler, buf, sender) -> {
			float forward = buf.readFloat();
			float turn = buf.readFloat();
			byte flags = buf.readByte();
			server.execute(() -> {
				if (player.getVehicle() instanceof ShipEntity ship) {
					ship.applyInput(player, forward, turn, (flags & 1) != 0, (flags & 2) != 0);
				}
			});
		});
		ServerPlayNetworking.registerGlobalReceiver(DOCK, (server, player, handler, buf, sender) -> server.execute(() -> {
			if (player.getVehicle() instanceof ShipEntity ship && ship.getPilot() == player) {
				ShipAssembler.disassemble(ship, player);
			}
		}));
	}
}
