package com.cloudwright.block;

import com.cloudwright.entity.ShipAssembler;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

/**
 * Штурвал. ПКМ — собрать судно из всех приклеенных блоков. Shift+ПКМ — посчитать вес и подъём без сборки.
 * Судно летит в ту сторону, куда смотрел игрок, когда ставил штурвал.
 */
public class HelmBlock extends HorizontalFacingBlock {
	private static final VoxelShape SHAPE = VoxelShapes.union(
			Block.createCuboidShape(3, 0, 3, 13, 2, 13),
			Block.createCuboidShape(7, 2, 7, 9, 12, 9),
			Block.createCuboidShape(2, 6, 2, 14, 16, 14));

	public HelmBlock(Settings settings) {
		super(settings);
		setDefaultState(getStateManager().getDefaultState().with(FACING, net.minecraft.util.math.Direction.NORTH));
	}

	@Override
	protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		return getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing());
	}

	@Override
	@SuppressWarnings("deprecation")
	public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return SHAPE;
	}

	@Override
	@SuppressWarnings("deprecation")
	public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
		if (hand != Hand.MAIN_HAND) return ActionResult.PASS;
		if (!world.isClient && world instanceof ServerWorld serverWorld) {
			if (player.isSneaking()) ShipAssembler.preview(serverWorld, pos, player);
			else ShipAssembler.assemble(serverWorld, pos, player);
		}
		return ActionResult.success(world.isClient);
	}
}
