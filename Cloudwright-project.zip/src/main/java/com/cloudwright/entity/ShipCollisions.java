package com.cloudwright.entity;

import com.cloudwright.mixin.ServerPlayNetworkHandlerAccessor;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Палуба как твёрдая поверхность: блоки судна становятся препятствием для игроков и мобов,
 * а тех, кто стоит на палубе, судно везёт с собой (и поворачивает вместе с собой).
 */
public final class ShipCollisions {
	/** Все судна в загруженных мирах (и клиентском, и серверном). */
	public static final Set<ShipEntity> ACTIVE = ConcurrentHashMap.newKeySet();

	private ShipCollisions() {
	}

	/** Вызывается из миксина Entity: добавляет к столкновениям формы блоков судов рядом. */
	public static List<VoxelShape> addShipShapes(Entity self, List<VoxelShape> list) {
		if (ACTIVE.isEmpty() || self instanceof ShipEntity || self.noClip || self.getVehicle() instanceof ShipEntity) return list;
		Box query = self.getBoundingBox().stretch(self.getVelocity()).expand(1.0);
		List<VoxelShape> out = null;
		for (Iterator<ShipEntity> it = ACTIVE.iterator(); it.hasNext(); ) {
			ShipEntity ship = it.next();
			if (ship.isRemoved()) {
				it.remove();
				continue;
			}
			if (ship.getWorld() != self.getWorld() || !ship.getBoundingBox().intersects(query)) continue;
			List<VoxelShape> shapes = shapes(ship, query, ship.getX(), ship.getY(), ship.getZ(), ship.currentYaw());
			if (shapes.isEmpty()) continue;
			if (out == null) out = new ArrayList<>(list);
			out.addAll(shapes);
		}
		return out == null ? list : out;
	}

	static BlockRotation nearestRotation(float yaw) {
		return switch (Math.floorMod(Math.round(yaw / 90f), 4)) {
			case 1 -> BlockRotation.CLOCKWISE_90;
			case 2 -> BlockRotation.CLOCKWISE_180;
			case 3 -> BlockRotation.COUNTERCLOCKWISE_90;
			default -> BlockRotation.NONE;
		};
	}

	/** Формы блоков судна (в мировых координатах), попадающих в query. */
	public static List<VoxelShape> shapes(ShipEntity ship, Box query, double px, double py, double pz, float yaw) {
		ShipData d = ship.getData();
		if (d == null || d.isEmpty()) return List.of();
		double r = Math.toRadians(yaw);
		double c = Math.cos(r), s = Math.sin(r);
		double lminX = Double.MAX_VALUE, lmaxX = -Double.MAX_VALUE, lminZ = Double.MAX_VALUE, lmaxZ = -Double.MAX_VALUE;
		double[][] corners = {{query.minX, query.minZ}, {query.maxX, query.minZ}, {query.minX, query.maxZ}, {query.maxX, query.maxZ}};
		for (double[] k : corners) {
			double dx = k[0] - px, dz = k[1] - pz;
			double lx = dx * c + dz * s;
			double lz = -dx * s + dz * c;
			lminX = Math.min(lminX, lx);
			lmaxX = Math.max(lmaxX, lx);
			lminZ = Math.min(lminZ, lz);
			lmaxZ = Math.max(lmaxZ, lz);
		}
		int x0 = Math.max(d.minX, MathHelper.floor(lminX + 0.5) - 1), x1 = Math.min(d.maxX, MathHelper.floor(lmaxX + 0.5) + 1);
		int z0 = Math.max(d.minZ, MathHelper.floor(lminZ + 0.5) - 1), z1 = Math.min(d.maxZ, MathHelper.floor(lmaxZ + 0.5) + 1);
		int y0 = Math.max(d.minY, MathHelper.floor(query.minY - py) - 1), y1 = Math.min(d.maxY, MathHelper.floor(query.maxY - py) + 1);
		if (x0 > x1 || y0 > y1 || z0 > z1) return List.of();
		BlockRotation rot = nearestRotation(yaw);
		List<VoxelShape> out = new ArrayList<>();
		BlockPos.Mutable m = new BlockPos.Mutable();
		for (int x = x0; x <= x1; x++) {
			for (int z = z0; z <= z1; z++) {
				for (int y = y0; y <= y1; y++) {
					BlockState st = d.byPos.get(m.set(x, y, z));
					if (st == null) continue;
					VoxelShape shape = d.collisionShape(st.rotate(rot));
					if (shape.isEmpty()) continue;
					double wx = px + x * c - z * s;
					double wz = pz + x * s + z * c;
					out.add(shape.offset(wx - 0.5, py + y, wz - 0.5));
				}
			}
		}
		return out;
	}

	/** Стоит ли сущность на палубе при данном положении судна. */
	public static boolean isStandingOn(ShipEntity ship, Entity e, double px, double py, double pz, float yaw) {
		Box b = e.getBoundingBox();
		Box feet = new Box(b.minX + 0.02, b.minY - 0.2, b.minZ + 0.02, b.maxX - 0.02, b.minY + 0.05, b.maxZ - 0.02);
		for (VoxelShape s : shapes(ship, feet, px, py, pz, yaw)) {
			if (s.getBoundingBoxes().stream().anyMatch(box -> box.intersects(feet))) return true;
		}
		return false;
	}

	/** Кого везти: на сервере — мобов и предметы, на клиенте — только своего игрока. */
	public static boolean shouldCarry(ShipEntity ship, Entity e) {
		if (e instanceof ShipEntity || e.hasVehicle() || e.noClip || e.isSpectator()) return false;
		if (e instanceof PlayerEntity p) return ship.getWorld().isClient && p.isMainPlayer();
		return !ship.getWorld().isClient;
	}

	public static List<Entity> collectRiders(ShipEntity ship) {
		List<Entity> out = new ArrayList<>();
		Box area = ship.getBoundingBox().expand(0.5, 2.0, 0.5);
		float yaw = ship.currentYaw();
		for (Entity e : ship.getWorld().getOtherEntities(ship, area)) {
			boolean carry = shouldCarry(ship, e);
			boolean serverPlayer = e instanceof ServerPlayerEntity;
			if (!carry && !serverPlayer) continue;
			if (!isStandingOn(ship, e, ship.getX(), ship.getY(), ship.getZ(), yaw)) continue;
			if (serverPlayer) {
				// игрок стоит на палубе — сервер не должен считать, что он «летает»
				ServerPlayerEntity sp = (ServerPlayerEntity) e;
				if (sp.networkHandler != null) ((ServerPlayNetworkHandlerAccessor) sp.networkHandler).cloudwright$setFloatingTicks(0);
				sp.fallDistance = 0;
			}
			if (carry) out.add(e);
		}
		return out;
	}

	/** Перенести стоящих вместе с судном: из старого положения/поворота в новое. */
	public static void carry(List<Entity> riders, Vec3d oldPos, float oldYaw, Vec3d newPos, float newYaw) {
		if (riders.isEmpty()) return;
		float dYaw = MathHelper.wrapDegrees(newYaw - oldYaw);
		if (oldPos.equals(newPos) && dYaw == 0) return;
		double ro = Math.toRadians(oldYaw), rn = Math.toRadians(newYaw);
		double co = Math.cos(ro), so = Math.sin(ro), cn = Math.cos(rn), sn = Math.sin(rn);
		for (Entity e : riders) {
			double dx = e.getX() - oldPos.x, dz = e.getZ() - oldPos.z;
			double lx = dx * co + dz * so;
			double lz = -dx * so + dz * co;
			double nx = newPos.x + lx * cn - lz * sn;
			double nz = newPos.z + lx * sn + lz * cn;
			double ny = e.getY() + (newPos.y - oldPos.y);
			e.setPosition(nx, ny, nz);
			e.fallDistance = 0;
			if (dYaw != 0) {
				e.setYaw(e.getYaw() + dYaw);
				e.setHeadYaw(e.getHeadYaw() + dYaw);
				if (e instanceof LivingEntity le) le.setBodyYaw(le.bodyYaw + dYaw);
			}
		}
	}
}
