package com.cloudwright.block;

import com.cloudwright.Cloudwright;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/** Горелка: греет воздух в оболочках. ПКМ топливом (уголь, блейз-стержень...) — заправить. */
public class BurnerBlock extends BlockWithEntity {
	public static final BooleanProperty LIT = Properties.LIT;
	/** Сколько топлива (в тиках горения) влезает в одну горелку: ~32 угля. */
	public static final int MAX_FUEL = 1600 * 32;

	public BurnerBlock(Settings settings) {
		super(settings);
		setDefaultState(getStateManager().getDefaultState().with(LIT, false));
	}

	@Override
	protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
		builder.add(LIT);
	}

	@Override
	@SuppressWarnings("deprecation")
	public BlockRenderType getRenderType(BlockState state) {
		return BlockRenderType.MODEL;
	}

	@Nullable
	@Override
	public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
		return new BurnerBlockEntity(pos, state);
	}

	@Override
	@SuppressWarnings("deprecation")
	public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
		ItemStack stack = player.getStackInHand(hand);
		if (!(world.getBlockEntity(pos) instanceof BurnerBlockEntity burner)) return ActionResult.PASS;
		Integer burn = stack.isEmpty() ? null : FuelRegistry.INSTANCE.get(stack.getItem());
		if (burn == null || burn <= 0) {
			if (!world.isClient && hand == Hand.MAIN_HAND) {
				player.sendMessage(Text.translatable("message.cloudwright.burner_fuel", burner.getFuelTicks() / 20), true);
			}
			return hand == Hand.MAIN_HAND ? ActionResult.success(world.isClient) : ActionResult.PASS;
		}
		if (burner.getFuelTicks() + burn > MAX_FUEL) {
			if (!world.isClient) player.sendMessage(Text.translatable("message.cloudwright.burner_full"), true);
			return ActionResult.success(world.isClient);
		}
		if (!world.isClient) {
			burner.addFuel(burn);
			if (!player.getAbilities().creativeMode) {
				ItemStack remainder = stack.getItem().getRecipeRemainder() != null
						? new ItemStack(stack.getItem().getRecipeRemainder()) : ItemStack.EMPTY;
				stack.decrement(1);
				if (!remainder.isEmpty() && !player.getInventory().insertStack(remainder)) player.dropItem(remainder, false);
			}
			if (!state.get(LIT)) world.setBlockState(pos, state.with(LIT, true));
			player.sendMessage(Text.translatable("message.cloudwright.burner_fuel", burner.getFuelTicks() / 20), true);
		}
		return ActionResult.success(world.isClient);
	}

	/** Блок горелки (наш или Blaze Burner из Create) и его мощность: сколько оболочек он прогревает. */
	public static int heatingPower(BlockState state) {
		if (state.isOf(Cloudwright.BURNER)) return 1;
		String id = net.minecraft.registry.Registries.BLOCK.getId(state.getBlock()).toString();
		if (id.equals("create:blaze_burner")) return 2;
		return 0;
	}
}
