package com.cloudwright.entity;

import com.cloudwright.Cloudwright;
import com.cloudwright.block.BurnerBlockEntity;
import com.cloudwright.block.HelmBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Сборка судна из блоков вокруг штурвала и разборка обратно на место стоянки. */
public final class ShipAssembler {
	/** Убрать блок без выпадения предметов и без обновления соседей. */
	private static final int REMOVE_FLAGS = Block.NOTIFY_LISTENERS | Block.FORCE_STATE | Block.SKIP_DROPS | Block.MOVED;
	private static final int PLACE_FLAGS = Block.NOTIFY_LISTENERS | Block.FORCE_STATE | Block.MOVED;

	private ShipAssembler() {
	}

	private static boolean canInclude(BlockState state) {
		if (state.isAir() || state.isReplaceable()) return false;
		if (!state.getFluidState().isEmpty() && state.getBlock() instanceof net.minecraft.block.FluidBlock) return false;
		if (state.isIn(Cloudwright.NOT_SHIP)) return false;
		return state.getHardness(net.minecraft.world.EmptyBlockView.INSTANCE, BlockPos.ORIGIN) >= 0;
	}

	/** Все блоки, соединённые со штурвалом (без земли). null — если судно слишком большое. */
	private static List<BlockPos> collect(ServerWorld world, BlockPos helm) {
		List<BlockPos> out = new ArrayList<>();
		Set<BlockPos> seen = new HashSet<>();
		ArrayDeque<BlockPos> queue = new ArrayDeque<>();
		queue.add(helm);
		seen.add(helm);
		while (!queue.isEmpty()) {
			BlockPos p = queue.poll();
			out.add(p);
			if (out.size() > ShipData.MAX_BLOCKS) return null;
			for (Direction d : Direction.values()) {
				BlockPos n = p.offset(d);
				if (seen.contains(n) || world.isOutOfHeightLimit(n)) continue;
				seen.add(n);
				if (canInclude(world.getBlockState(n))) queue.add(n);
			}
		}
		return out;
	}

	private static ShipData snapshot(ServerWorld world, BlockPos helm, List<BlockPos> positions) {
		List<ShipData.ShipBlock> blocks = new ArrayList<>();
		for (BlockPos p : positions) {
			BlockState s = world.getBlockState(p);
			BlockEntity be = world.getBlockEntity(p);
			NbtCompound nbt = be != null ? be.createNbt() : null;
			blocks.add(new ShipData.ShipBlock(p.subtract(helm).toImmutable(), s, nbt));
		}
		Direction forward = world.getBlockState(helm).get(HelmBlock.FACING);
		return new ShipData(blocks, forward);
	}

	public static void preview(ServerWorld world, BlockPos helm, PlayerEntity player) {
		List<BlockPos> positions = collect(world, helm);
		if (positions == null) {
			player.sendMessage(Text.translatable("message.cloudwright.too_big", ShipData.MAX_BLOCKS), false);
			return;
		}
		ShipData data = snapshot(world, helm, positions);
		int fuel = 0;
		for (BlockPos p : positions) {
			if (world.getBlockEntity(p) instanceof BurnerBlockEntity b) fuel += b.getFuelTicks();
		}
		float lift = data.liftAt(data.maxHeat());
		player.sendMessage(Text.translatable("message.cloudwright.preview_title"), false);
		player.sendMessage(Text.translatable("message.cloudwright.preview_blocks", data.blocks.size(),
				fmt(data.mass), fmt(lift)), false);
		player.sendMessage(Text.translatable("message.cloudwright.preview_parts", data.envelopes, data.burnerPower,
				data.etherite, data.vents, fmt(data.thrust), data.gyros, fuel / 20), false);
		String verdict;
		if (lift <= data.mass) verdict = "message.cloudwright.verdict_heavy";
		else if (lift < data.mass * 1.15f) verdict = "message.cloudwright.verdict_barely";
		else verdict = "message.cloudwright.verdict_ok";
		player.sendMessage(Text.translatable(verdict), false);
	}

	public static void assemble(ServerWorld world, BlockPos helm, PlayerEntity player) {
		List<BlockPos> positions = collect(world, helm);
		if (positions == null) {
			player.sendMessage(Text.translatable("message.cloudwright.too_big", ShipData.MAX_BLOCKS), true);
			return;
		}
		if (positions.size() < 2) {
			player.sendMessage(Text.translatable("message.cloudwright.nothing_attached"), true);
			return;
		}
		ShipData data = snapshot(world, helm, positions);
		int fuel = 0;
		List<ShipData.ShipBlock> fixed = new ArrayList<>();
		for (ShipData.ShipBlock b : data.blocks) {
			NbtCompound nbt = b.be();
			if (nbt != null && nbt.contains(BurnerBlockEntity.FUEL_KEY)) {
				fuel += nbt.getInt(BurnerBlockEntity.FUEL_KEY);
				nbt = nbt.copy();
				nbt.putInt(BurnerBlockEntity.FUEL_KEY, 0);
			}
			fixed.add(new ShipData.ShipBlock(b.rel(), b.state(), nbt));
		}
		ShipData ship = new ShipData(fixed, data.forward);

		ShipEntity entity = new ShipEntity(Cloudwright.SHIP, world);
		entity.initShip(ship, fuel);
		entity.setPosition(helm.getX() + 0.5, helm.getY(), helm.getZ() + 0.5);

		// сначала снимаем блок-сущности (чтобы сундуки не высыпали вещи), потом сами блоки — сверху вниз
		positions.sort((a, b) -> Integer.compare(b.getY(), a.getY()));
		for (BlockPos p : positions) world.removeBlockEntity(p);
		for (BlockPos p : positions) world.setBlockState(p, Blocks.AIR.getDefaultState(), REMOVE_FLAGS);
		for (BlockPos p : positions) world.updateNeighbors(p, Blocks.AIR);

		world.spawnEntity(entity);
		if (!player.hasVehicle()) player.startRiding(entity);
		player.sendMessage(Text.translatable("message.cloudwright.assembled", ship.blocks.size()), true);
	}

	/** Поставить судно обратно блоками. false — если не получилось (нет места, слишком быстро, криво стоит). */
	public static boolean disassemble(ShipEntity ship, PlayerEntity player) {
		if (!(ship.getWorld() instanceof ServerWorld world)) return false;
		ShipData data = ship.getData();
		if (data == null || data.isEmpty()) return false;
		if (ship.getVelocity().length() > 0.12) {
			player.sendMessage(Text.translatable("message.cloudwright.dock_slow_down"), true);
			return false;
		}
		float yaw = ship.getShipYaw();
		int steps = Math.round(yaw / 90f);
		if (Math.abs(yaw - steps * 90f) > 25f) {
			player.sendMessage(Text.translatable("message.cloudwright.dock_align"), true);
			return false;
		}
		BlockRotation rotation = switch (Math.floorMod(steps, 4)) {
			case 1 -> BlockRotation.CLOCKWISE_90;
			case 2 -> BlockRotation.CLOCKWISE_180;
			case 3 -> BlockRotation.COUNTERCLOCKWISE_90;
			default -> BlockRotation.NONE;
		};
		BlockPos origin = BlockPos.ofFloored(ship.getX(), Math.round(ship.getY()), ship.getZ());
		List<BlockPos> targets = new ArrayList<>();
		for (ShipData.ShipBlock b : data.blocks) {
			BlockPos t = origin.add(b.rel().rotate(rotation));
			if (world.isOutOfHeightLimit(t) || !world.getBlockState(t).isReplaceable()) {
				player.sendMessage(Text.translatable("message.cloudwright.dock_blocked", t.getX(), t.getY(), t.getZ()), true);
				return false;
			}
			targets.add(t);
		}
		int fuelLeft = Math.round(ship.getFuel());
		boolean fuelPlaced = false;
		ship.removeAllPassengers();
		for (int i = 0; i < data.blocks.size(); i++) {
			ShipData.ShipBlock b = data.blocks.get(i);
			BlockPos t = targets.get(i);
			BlockState s = b.state().rotate(rotation);
			world.setBlockState(t, s, PLACE_FLAGS);
			if (b.be() != null) {
				BlockEntity be = world.getBlockEntity(t);
				if (be != null) {
					NbtCompound nbt = b.be().copy();
					if (!fuelPlaced && be instanceof BurnerBlockEntity) {
						nbt.putInt(BurnerBlockEntity.FUEL_KEY, Math.min(com.cloudwright.block.BurnerBlock.MAX_FUEL, fuelLeft));
						fuelPlaced = true;
					}
					nbt.putInt("x", t.getX());
					nbt.putInt("y", t.getY());
					nbt.putInt("z", t.getZ());
					be.readNbt(nbt);
					be.markDirty();
				}
			}
		}
		for (int i = 0; i < targets.size(); i++) world.updateNeighbors(targets.get(i), data.blocks.get(i).state().getBlock());
		ship.discard();
		player.sendMessage(Text.translatable("message.cloudwright.docked"), true);
		return true;
	}

	static String fmt(float v) {
		return String.format(Locale.ROOT, "%.1f", v);
	}
}
