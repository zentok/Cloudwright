package com.cloudwright.block;

import com.cloudwright.Cloudwright;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.BlockPos;

/** Хранит запас топлива горелки (в тиках горения). Пока горелка стоит на земле, топливо не тратится. */
public class BurnerBlockEntity extends BlockEntity {
	public static final String FUEL_KEY = "FuelTicks";
	private int fuelTicks;

	public BurnerBlockEntity(BlockPos pos, BlockState state) {
		super(Cloudwright.BURNER_ENTITY, pos, state);
	}

	public int getFuelTicks() {
		return fuelTicks;
	}

	public void addFuel(int ticks) {
		fuelTicks = Math.min(BurnerBlock.MAX_FUEL, fuelTicks + Math.max(0, ticks));
		markDirty();
	}

	@Override
	public void readNbt(NbtCompound nbt) {
		super.readNbt(nbt);
		fuelTicks = Math.max(0, nbt.getInt(FUEL_KEY));
	}

	@Override
	protected void writeNbt(NbtCompound nbt) {
		super.writeNbt(nbt);
		nbt.putInt(FUEL_KEY, fuelTicks);
	}
}
