package com.cloudwright.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/** Блок эфирита: парящий кристалл. На судне даёт постоянную подъёмную силу без горелки. */
public class EtheriteBlock extends Block {
	public EtheriteBlock(Settings settings) {
		super(settings);
	}

	@Override
	public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
		if (random.nextInt(3) == 0) {
			world.addParticle(ParticleTypes.END_ROD, pos.getX() + random.nextDouble(), pos.getY() + 1.05,
					pos.getZ() + random.nextDouble(), 0, 0.02, 0);
		}
	}
}
