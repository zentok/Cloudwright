package com.cloudwright.client;

import com.cloudwright.Cloudwright;
import com.cloudwright.entity.ShipEntity;
import com.cloudwright.net.CloudwrightNetworking;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.PacketByteBuf;
import org.lwjgl.glfw.GLFW;

public class CloudwrightClient implements ClientModInitializer {
	public static KeyBinding DESCEND;
	public static KeyBinding DOCK;

	private float lastForward, lastTurn;
	private byte lastFlags;
	private int resendTimer;

	@Override
	public void onInitializeClient() {
		EntityRendererRegistry.register(Cloudwright.SHIP, ShipRenderer::new);
		BlockRenderLayerMap.INSTANCE.putBlocks(RenderLayer.getCutout(), Cloudwright.HELM, Cloudwright.STEAM_VENT,
				Cloudwright.WOODEN_PROPELLER, Cloudwright.ANDESITE_PROPELLER, Cloudwright.SMART_PROPELLER);

		DESCEND = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.cloudwright.descend",
				InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "key.categories.cloudwright"));
		DOCK = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.cloudwright.dock",
				InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, "key.categories.cloudwright"));

		ClientTickEvents.END_CLIENT_TICK.register(this::tick);
		HudRenderCallback.EVENT.register(ShipHud::render);
	}

	private void tick(MinecraftClient client) {
		if (client.player == null || !(client.player.getVehicle() instanceof ShipEntity ship)) {
			while (DOCK.wasPressed()) {
				// просто сбрасываем нажатия вне судна
			}
			return;
		}
		boolean pilot = ship.getFirstPassenger() == client.player;
		while (DOCK.wasPressed()) {
			if (pilot) ClientPlayNetworking.send(CloudwrightNetworking.DOCK, PacketByteBufs.empty());
		}
		if (!pilot || client.player.input == null) return;
		float forward = client.player.input.movementForward;
		float turn = client.player.input.movementSideways;
		byte flags = 0;
		if (client.player.input.jumping) flags |= 1;
		if (DESCEND.isPressed()) flags |= 2;
		if (client.currentScreen != null) {
			forward = turn = 0;
			flags = 0;
		}
		resendTimer++;
		if (forward != lastForward || turn != lastTurn || flags != lastFlags || resendTimer >= 10) {
			PacketByteBuf buf = PacketByteBufs.create();
			buf.writeFloat(forward);
			buf.writeFloat(turn);
			buf.writeByte(flags);
			ClientPlayNetworking.send(CloudwrightNetworking.INPUT, buf);
			lastForward = forward;
			lastTurn = turn;
			lastFlags = flags;
			resendTimer = 0;
		}
	}
}
