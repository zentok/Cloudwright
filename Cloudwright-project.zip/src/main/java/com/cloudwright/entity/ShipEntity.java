package com.cloudwright.entity;

import com.cloudwright.Cloudwright;
import com.cloudwright.block.BurnerBlock;
import com.cloudwright.block.PropellerBlock;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/**
 * Летящее судно. Хранит свои блоки (координаты относительно штурвала), считает физику на сервере,
 * клиент только плавно догоняет присланное положение и рисует блоки.
 */
public class ShipEntity extends Entity {
	private static final TrackedData<NbtCompound> BLOCKS = DataTracker.registerData(ShipEntity.class, TrackedDataHandlerRegistry.NBT_COMPOUND);
	private static final TrackedData<Float> SHIP_YAW = DataTracker.registerData(ShipEntity.class, TrackedDataHandlerRegistry.FLOAT);
	private static final TrackedData<Float> TILT_X = DataTracker.registerData(ShipEntity.class, TrackedDataHandlerRegistry.FLOAT);
	private static final TrackedData<Float> TILT_Z = DataTracker.registerData(ShipEntity.class, TrackedDataHandlerRegistry.FLOAT);
	private static final TrackedData<Float> HEAT = DataTracker.registerData(ShipEntity.class, TrackedDataHandlerRegistry.FLOAT);
	private static final TrackedData<Float> THROTTLE = DataTracker.registerData(ShipEntity.class, TrackedDataHandlerRegistry.FLOAT);
	private static final TrackedData<Float> FUEL = DataTracker.registerData(ShipEntity.class, TrackedDataHandlerRegistry.FLOAT);
	private static final TrackedData<Float> PROP_SPEED = DataTracker.registerData(ShipEntity.class, TrackedDataHandlerRegistry.FLOAT);
	private static final TrackedData<Boolean> VENTING = DataTracker.registerData(ShipEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

	public static final float MAX_TILT = 30f;
	private static final double MAX_SPEED = 0.9;

	@Nullable
	private ShipData data;

	// ---- сервер: состояние полёта
	private float shipYaw;
	private float yawRate;
	private float tiltX, tiltZ;
	private float heat;
	private float throttle;
	private float fuel;
	private boolean grounded = true;

	// ---- сервер: ввод пилота
	private float inForward, inTurn;
	private boolean inUp, inDown;
	private int inputAge = 100;

	// ---- клиент: плавность
	private double lerpX, lerpY, lerpZ;
	private int lerpSteps;
	public float renderYaw, prevRenderYaw;
	public float renderTiltX, prevRenderTiltX, renderTiltZ, prevRenderTiltZ;
	public float spin, prevSpin;
	private float clientYawDelta;

	public ShipEntity(EntityType<? extends ShipEntity> type, World world) {
		super(type, world);
	}

	// ================================================================ данные

	public void initShip(ShipData data, int fuel) {
		this.data = data;
		this.fuel = Math.min(fuel, maxFuel());
		this.dataTracker.set(BLOCKS, data.toNbt());
		this.dataTracker.set(FUEL, this.fuel);
		refreshBox();
	}

	@Nullable
	public ShipData getData() {
		return data;
	}

	/** Текущий поворот: на клиенте — сглаженный, на сервере — настоящий. */
	public float currentYaw() {
		return getWorld().isClient ? renderYaw : shipYaw;
	}

	public float getShipYaw() {
		return getWorld().isClient ? renderYaw : shipYaw;
	}

	public float getFuel() {
		return dataTracker.get(FUEL);
	}

	public float getHeat() {
		return dataTracker.get(HEAT);
	}

	public float getThrottle() {
		return dataTracker.get(THROTTLE);
	}

	public boolean isVenting() {
		return dataTracker.get(VENTING);
	}

	public int maxFuel() {
		return data == null ? 0 : data.burners.size() * BurnerBlock.MAX_FUEL;
	}

	/** Плотность воздуха: чем выше, тем меньше подъём от горячего воздуха (естественный «потолок»). */
	public static float airDensity(double y) {
		return (float) MathHelper.clamp(1.0 - (y - 80.0) / 400.0, 0.4, 1.0);
	}

	public float currentLift() {
		if (data == null) return 0;
		return data.envelopes * ShipData.ENVELOPE_LIFT * getHeat() * airDensity(getY()) + data.etherite * ShipData.ETHERITE_LIFT;
	}

	@Override
	protected void initDataTracker() {
		dataTracker.startTracking(BLOCKS, new NbtCompound());
		dataTracker.startTracking(SHIP_YAW, 0f);
		dataTracker.startTracking(TILT_X, 0f);
		dataTracker.startTracking(TILT_Z, 0f);
		dataTracker.startTracking(HEAT, 0f);
		dataTracker.startTracking(THROTTLE, 0f);
		dataTracker.startTracking(FUEL, 0f);
		dataTracker.startTracking(PROP_SPEED, 0f);
		dataTracker.startTracking(VENTING, false);
	}

	@Override
	public void onTrackedDataSet(TrackedData<?> key) {
		super.onTrackedDataSet(key);
		if (BLOCKS.equals(key) && getWorld().isClient) {
			NbtCompound tag = dataTracker.get(BLOCKS);
			data = tag.isEmpty() ? null : ShipData.fromNbt(tag);
			refreshBox();
		} else if (SHIP_YAW.equals(key) && getWorld().isClient && lerpSteps == 0 && age < 2) {
			renderYaw = prevRenderYaw = dataTracker.get(SHIP_YAW);
			refreshBox();
		}
	}

	@Override
	protected void readCustomDataFromNbt(NbtCompound nbt) {
		if (nbt.contains("Ship")) {
			data = ShipData.fromNbt(nbt.getCompound("Ship"));
			dataTracker.set(BLOCKS, data.toNbt());
		}
		shipYaw = nbt.getFloat("ShipYaw");
		throttle = nbt.getFloat("Throttle");
		heat = nbt.getFloat("Heat");
		fuel = nbt.getFloat("Fuel");
		dataTracker.set(SHIP_YAW, shipYaw);
		dataTracker.set(FUEL, fuel);
		refreshBox();
	}

	@Override
	protected void writeCustomDataToNbt(NbtCompound nbt) {
		if (data != null) nbt.put("Ship", data.toNbt());
		nbt.putFloat("ShipYaw", shipYaw);
		nbt.putFloat("Throttle", throttle);
		nbt.putFloat("Heat", heat);
		nbt.putFloat("Fuel", fuel);
	}

	@Override
	public Packet<ClientPlayPacketListener> createSpawnPacket() {
		return new EntitySpawnS2CPacket(this);
	}

	// ================================================================ геометрия

	/** Локальная точка судна (относительно штурвала, без наклона) → мир. */
	public Vec3d localToWorld(double lx, double ly, double lz, float yawDeg) {
		double r = Math.toRadians(yawDeg);
		double c = Math.cos(r), s = Math.sin(r);
		return new Vec3d(getX() + lx * c - lz * s, getY() + ly, getZ() + lx * s + lz * c);
	}

	/** То же, но с учётом наклона (для пассажиров и частиц). */
	public Vec3d localToWorldTilted(double lx, double ly, double lz, float yawDeg, float tx, float tz) {
		if (data == null) return localToWorld(lx, ly, lz, yawDeg);
		Vec3d com = data.centerOfMass;
		Vector3f v = new Vector3f((float) (lx - com.x), (float) (ly - com.y), (float) (lz - com.z));
		new Quaternionf().rotateY((float) Math.toRadians(-yawDeg))
				.rotateX((float) Math.toRadians(tx))
				.rotateZ((float) Math.toRadians(tz))
				.transform(v);
		Vec3d c = rotateXZ(com.x, com.z, yawDeg);
		return new Vec3d(getX() + c.x + v.x, getY() + com.y + v.y, getZ() + c.z + v.z);
	}

	private static Vec3d rotateXZ(double x, double z, float yawDeg) {
		double r = Math.toRadians(yawDeg);
		double c = Math.cos(r), s = Math.sin(r);
		return new Vec3d(x * c - z * s, 0, x * s + z * c);
	}

	private void refreshBox() {
		setPosition(getX(), getY(), getZ());
	}

	@Override
	protected Box calculateBoundingBox() {
		if (data == null || data.isEmpty()) return super.calculateBoundingBox();
		float yaw = getWorld() != null && getWorld().isClient ? renderYaw : shipYaw;
		double minX = Double.MAX_VALUE, minZ = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
		double[][] corners = {
				{data.minX - 0.5, data.minZ - 0.5}, {data.maxX + 0.5, data.minZ - 0.5},
				{data.minX - 0.5, data.maxZ + 0.5}, {data.maxX + 0.5, data.maxZ + 0.5}};
		for (double[] c : corners) {
			Vec3d w = rotateXZ(c[0], c[1], yaw);
			minX = Math.min(minX, w.x);
			maxX = Math.max(maxX, w.x);
			minZ = Math.min(minZ, w.z);
			maxZ = Math.max(maxZ, w.z);
		}
		return new Box(getX() + minX, getY() + data.minY, getZ() + minZ, getX() + maxX, getY() + data.maxY + 1, getZ() + maxZ);
	}

	/** Коробки внешних блоков корпуса в мире (поворот учитывается, наклон — нет). */
	private List<Box> hullBoxes(double px, double py, double pz, float yaw) {
		List<Box> out = new ArrayList<>(data.hull.size());
		double r = Math.toRadians(yaw);
		double c = Math.cos(r), s = Math.sin(r);
		for (BlockPos rel : data.hull) {
			double wx = px + rel.getX() * c - rel.getZ() * s;
			double wz = pz + rel.getX() * s + rel.getZ() * c;
			double wy = py + rel.getY();
			out.add(new Box(wx - 0.49, wy, wz - 0.49, wx + 0.49, wy + 0.999, wz + 0.49));
		}
		return out;
	}

	private boolean anyBlockCollision(Box box) {
		for (VoxelShape s : getWorld().getBlockCollisions(null, box)) {
			if (!s.isEmpty()) return true;
		}
		return false;
	}

	private double clipAxis(Direction.Axis axis, double d, List<Box> boxes) {
		if (Math.abs(d) < 1.0E-7) return 0;
		for (Box b : boxes) {
			Box swept = b.stretch(axis == Direction.Axis.X ? d : 0, axis == Direction.Axis.Y ? d : 0, axis == Direction.Axis.Z ? d : 0);
			d = VoxelShapes.calculateMaxOffset(axis, b, getWorld().getBlockCollisions(null, swept), d);
			if (Math.abs(d) < 1.0E-7) return 0;
		}
		return d;
	}

	private static List<Box> offsetAll(List<Box> boxes, double x, double y, double z) {
		if (x == 0 && y == 0 && z == 0) return boxes;
		List<Box> out = new ArrayList<>(boxes.size());
		for (Box b : boxes) out.add(b.offset(x, y, z));
		return out;
	}

	// ================================================================ взаимодействие

	@Override
	public ActionResult interact(PlayerEntity player, Hand hand) {
		if (data == null) return ActionResult.PASS;
		ItemStack stack = player.getStackInHand(hand);
		Integer burn = stack.isEmpty() ? null : FuelRegistry.INSTANCE.get(stack.getItem());
		if (burn != null && burn > 0 && !data.burners.isEmpty()) {
			if (!getWorld().isClient) {
				if (fuel + burn > maxFuel()) {
					player.sendMessage(Text.translatable("message.cloudwright.burner_full"), true);
				} else {
					fuel += burn;
					dataTracker.set(FUEL, fuel);
					if (!player.getAbilities().creativeMode) {
						ItemStack rem = stack.getItem().getRecipeRemainder() != null
								? new ItemStack(stack.getItem().getRecipeRemainder()) : ItemStack.EMPTY;
						stack.decrement(1);
						if (!rem.isEmpty() && !player.getInventory().insertStack(rem)) player.dropItem(rem, false);
					}
					getWorld().playSound(null, getBlockPos(), SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.NEUTRAL, 0.5f, 1.2f);
					player.sendMessage(Text.translatable("message.cloudwright.ship_fuel", Math.round(fuel / 20)), true);
				}
			}
			return ActionResult.success(getWorld().isClient);
		}
		if (player.getVehicle() == this) return ActionResult.PASS;
		if (player.shouldCancelInteraction()) return ActionResult.PASS;
		if (!getWorld().isClient) {
			if (!player.startRiding(this)) player.sendMessage(Text.translatable("message.cloudwright.no_seats"), true);
		}
		return ActionResult.success(getWorld().isClient);
	}

	@Override
	protected boolean canAddPassenger(Entity passenger) {
		return data != null && getPassengerList().size() < 1 + data.seats.size();
	}

	@Nullable
	public PlayerEntity getPilot() {
		return getFirstPassenger() instanceof PlayerEntity p ? p : null;
	}

	@Nullable
	private Vec3d pilotSeatCache;
	@Nullable
	private ShipData pilotSeatFor;

	/** Место пилота: за штурвалом, на первой свободной высоте. */
	private Vec3d pilotSeatLocal() {
		if (pilotSeatCache != null && pilotSeatFor == data) return pilotSeatCache;
		Direction f = data.forward;
		int bx = -f.getOffsetX(), bz = -f.getOffsetZ();
		int y = 0;
		java.util.Set<BlockPos> occ = new java.util.HashSet<>();
		for (ShipData.ShipBlock b : data.blocks) occ.add(b.rel());
		while (y < 4 && occ.contains(new BlockPos(bx, y, bz))) y++;
		pilotSeatFor = data;
		pilotSeatCache = new Vec3d(bx, y, bz);
		return pilotSeatCache;
	}

	private Vec3d seatLocal(Entity passenger) {
		int idx = getPassengerList().indexOf(passenger);
		if (idx <= 0 || data.seats.isEmpty()) return pilotSeatLocal();
		BlockPos s = data.seats.get(Math.min(idx - 1, data.seats.size() - 1));
		return new Vec3d(s.getX(), s.getY() + 0.5, s.getZ());
	}

	@Override
	protected void updatePassengerPosition(Entity passenger, PositionUpdater positionUpdater) {
		if (!hasPassenger(passenger)) return;
		if (data == null) {
			super.updatePassengerPosition(passenger, positionUpdater);
			return;
		}
		Vec3d local = seatLocal(passenger);
		boolean client = getWorld().isClient;
		float yaw = client ? renderYaw : shipYaw;
		float tx = client ? renderTiltX : tiltX;
		float tz = client ? renderTiltZ : tiltZ;
		Vec3d w = localToWorldTilted(local.x, local.y + 0.35, local.z, yaw, tx, tz);
		positionUpdater.accept(passenger, w.x, w.y + passenger.getHeightOffset(), w.z);
		if (client && clientYawDelta != 0) {
			passenger.setYaw(passenger.getYaw() + clientYawDelta);
			passenger.setHeadYaw(passenger.getHeadYaw() + clientYawDelta);
			if (passenger instanceof LivingEntity le) le.setBodyYaw(le.bodyYaw + clientYawDelta);
		}
	}

	@Override
	public Vec3d updatePassengerForDismount(LivingEntity passenger) {
		if (data != null) {
			// встаём прямо на палубу у своего места
			Vec3d local = seatLocal(passenger);
			Vec3d w = localToWorld(local.x, local.y, local.z, shipYaw);
			Box pb = passenger.getBoundingBox();
			Box test = pb.offset(w.x - passenger.getX(), w.y + 0.01 - passenger.getY(), w.z - passenger.getZ());
			if (!anyBlockCollision(test) && ShipCollisions.shapes(this, test.contract(0.05), getX(), getY(), getZ(), shipYaw).stream()
					.noneMatch(sh -> sh.getBoundingBoxes().stream().anyMatch(bb -> bb.intersects(test.contract(0.05))))) {
				return new Vec3d(w.x, w.y + 0.01, w.z);
			}
		}
		Box box = getBoundingBox();
		Vec3d p = passenger.getPos();
		double toMinX = p.x - box.minX, toMaxX = box.maxX - p.x, toMinZ = p.z - box.minZ, toMaxZ = box.maxZ - p.z;
		double m = Math.min(Math.min(toMinX, toMaxX), Math.min(toMinZ, toMaxZ));
		double x = p.x, z = p.z;
		if (m == toMinX) x = box.minX - 0.7;
		else if (m == toMaxX) x = box.maxX + 0.7;
		else if (m == toMinZ) z = box.minZ - 0.7;
		else z = box.maxZ + 0.7;
		Box pb = passenger.getBoundingBox();
		for (int dy = 2; dy >= -10; dy--) {
			double y = Math.floor(box.minY) + dy;
			Box test = pb.offset(x - passenger.getX(), y - passenger.getY(), z - passenger.getZ());
			if (!anyBlockCollision(test) && anyBlockCollision(test.offset(0, -0.5, 0).shrink(0, 0.4, 0))) {
				return new Vec3d(x, y, z);
			}
		}
		return new Vec3d(x, box.minY, z);
	}

	/** Ввод пилота (приходит пакетом). */
	public void applyInput(PlayerEntity player, float forward, float turn, boolean up, boolean down) {
		if (getPilot() != player) return;
		inForward = MathHelper.clamp(forward, -1, 1);
		inTurn = MathHelper.clamp(turn, -1, 1);
		inUp = up;
		inDown = down;
		inputAge = 0;
	}

	@Override
	public boolean damage(DamageSource source, float amount) {
		return false;
	}

	@Override
	public boolean canHit() {
		return !isRemoved();
	}

	@Override
	public boolean isCollidable() {
		return false;
	}

	@Override
	public boolean isPushable() {
		return false;
	}

	@Override
	public boolean isFireImmune() {
		return true;
	}

	@Override
	public boolean canUsePortals() {
		return false;
	}

	@Override
	public ItemStack getPickBlockStack() {
		return new ItemStack(Cloudwright.HELM);
	}

	@Override
	public boolean shouldRender(double distance) {
		double d = getBoundingBox().getAverageSideLength() * 4.0 + 64.0;
		return distance < d * d * 4;
	}

	// ================================================================ тик

	@Override
	public void tick() {
		super.tick();
		if (!isRemoved()) ShipCollisions.ACTIVE.add(this);
		if (getWorld().isClient) {
			clientTick();
			return;
		}
		if (data == null || data.isEmpty()) {
			discard();
			return;
		}
		serverTick();
	}

	@Override
	public void updateTrackedPositionAndAngles(double x, double y, double z, float yaw, float pitch, int steps, boolean interpolate) {
		lerpX = x;
		lerpY = y;
		lerpZ = z;
		lerpSteps = 3;
	}

	private void clientTick() {
		List<Entity> riders = data != null ? ShipCollisions.collectRiders(this) : List.of();
		Vec3d oldPos = getPos();
		float oldYaw = renderYaw;
		if (lerpSteps > 0) {
			double nx = getX() + (lerpX - getX()) / lerpSteps;
			double ny = getY() + (lerpY - getY()) / lerpSteps;
			double nz = getZ() + (lerpZ - getZ()) / lerpSteps;
			lerpSteps--;
			setPosition(nx, ny, nz);
		}
		prevRenderYaw = renderYaw;
		float targetYaw = dataTracker.get(SHIP_YAW);
		float diff = MathHelper.wrapDegrees(targetYaw - renderYaw);
		float step = Math.abs(diff) > 45 ? diff : diff * 0.5f;
		renderYaw = renderYaw + step;
		clientYawDelta = renderYaw - prevRenderYaw;
		// чтобы lerp между prev и текущим не крутил через полный круг
		if (renderYaw > 180f) {
			renderYaw -= 360f;
			prevRenderYaw -= 360f;
		} else if (renderYaw < -180f) {
			renderYaw += 360f;
			prevRenderYaw += 360f;
		}
		prevRenderTiltX = renderTiltX;
		prevRenderTiltZ = renderTiltZ;
		renderTiltX += (dataTracker.get(TILT_X) - renderTiltX) * 0.5f;
		renderTiltZ += (dataTracker.get(TILT_Z) - renderTiltZ) * 0.5f;
		prevSpin = spin;
		spin += dataTracker.get(PROP_SPEED) * 40f;
		if (spin > 3600f) {
			spin -= 3600f;
			prevSpin -= 3600f;
		}
		if (clientYawDelta != 0) refreshBox();
		ShipCollisions.carry(riders, oldPos, oldYaw, getPos(), renderYaw);
		spawnParticles();
	}

	private void spawnParticles() {
		if (data == null) return;
		World w = getWorld();
		float h = getHeat();
		if (h > 0.02f && getFuel() > 0) {
			for (BlockPos b : data.burners) {
				if (random.nextFloat() < 0.3f + h * 0.5f) {
					Vec3d p = localToWorldTilted(b.getX() + (random.nextDouble() - 0.5) * 0.4, b.getY() + 1.05,
							b.getZ() + (random.nextDouble() - 0.5) * 0.4, renderYaw, renderTiltX, renderTiltZ);
					w.addParticle(ParticleTypes.FLAME, p.x, p.y, p.z, 0, 0.03 + h * 0.05, 0);
				}
			}
		}
		if (isVenting()) {
			for (BlockPos b : data.ventPositions) {
				Vec3d p = localToWorldTilted(b.getX(), b.getY() + 1.0, b.getZ(), renderYaw, renderTiltX, renderTiltZ);
				w.addParticle(ParticleTypes.CLOUD, p.x, p.y, p.z, (random.nextDouble() - 0.5) * 0.05, 0.25, (random.nextDouble() - 0.5) * 0.05);
			}
		}
	}

	private void serverTick() {
		if (inputAge++ > 20 || getPilot() == null) {
			inForward = inTurn = 0;
			inUp = inDown = false;
		}
		float mass = Math.max(data.mass, 1f);
		List<Entity> riders = ShipCollisions.collectRiders(this);
		Vec3d oldPos = getPos();
		float oldYaw = shipYaw;

		// --- горелки и нагрев
		if (inUp) throttle = Math.min(1f, throttle + 0.01f);
		if (inDown) throttle = Math.max(0f, throttle - 0.02f);
		boolean hasFuel = fuel > 0 && data.burnerPower > 0;
		float targetHeat = hasFuel ? throttle * data.maxHeat() : 0f;
		if (heat < targetHeat) {
			heat = Math.min(targetHeat, heat + 0.006f);
		} else {
			float cool = 0.0015f + (inDown ? 0.003f + data.vents * 0.004f : 0f);
			heat = Math.max(targetHeat, heat - cool);
		}
		boolean propsOn = hasFuel && data.thrust > 0;
		if (hasFuel) {
			fuel -= data.burnerPower * throttle + (propsOn ? 0.5f * Math.abs(inForward) : 0f);
			if (fuel < 0) fuel = 0;
		}

		// --- вертикаль: подъём против веса
		float lift = data.envelopes * ShipData.ENVELOPE_LIFT * heat * airDensity(getY()) + data.etherite * ShipData.ETHERITE_LIFT;
		Vec3d v = getVelocity();
		double ay = MathHelper.clamp((lift - data.mass) / mass * 0.05, -0.05, 0.04);
		double vy = MathHelper.clamp(v.y * 0.96 + ay, -0.8, 0.5);

		// --- тяга пропеллеров
		float yawBefore = shipYaw;
		Vec3d fwd = rotateXZ(data.forward.getOffsetX(), data.forward.getOffsetZ(), shipYaw);
		double acc = propsOn ? data.thrust * inForward * 0.1 / mass : 0;
		double drag = grounded ? 0.6 : 0.97;
		double vx = v.x * drag + fwd.x * acc;
		double vz = v.z * drag + fwd.z * acc;

		// --- снос от перекоса: судно «съезжает» в сторону опущенного борта
		if (!grounded) {
			Vec3d drift = rotateXZ(-Math.sin(Math.toRadians(tiltZ)) * 0.004, Math.sin(Math.toRadians(tiltX)) * 0.004, shipYaw);
			vx += drift.x;
			vz += drift.z;
		}
		double hs = Math.sqrt(vx * vx + vz * vz);
		if (hs > MAX_SPEED) {
			vx *= MAX_SPEED / hs;
			vz *= MAX_SPEED / hs;
		}

		// --- поворот (влево — минус)
		float turnAcc = grounded ? 0f : (propsOn ? 0.35f : 0.12f) * -inTurn / (float) Math.sqrt(mass / 20f + 0.5f);
		yawRate = MathHelper.clamp(yawRate * 0.85f + turnAcc, -3f, 3f);
		if (Math.abs(yawRate) > 0.01f) tryRotate(yawRate);
		else yawRate = 0;

		// --- наклон: центр подъёма не над центром тяжести → крен/дифферент, гироскопы выравнивают
		float tx = 0, tz = 0;
		if (!grounded && lift > 0) {
			Vec3d off = data.centerOfLift.subtract(data.centerOfMass);
			float share = Math.min(1f, lift / mass);
			tx = (float) (-off.z * 8.0 * share);
			tz = (float) (off.x * 8.0 * share);
			float gyro = Math.max(0f, 1f - 0.5f * data.gyros);
			tx *= gyro;
			tz *= gyro;
		}
		tiltX += (MathHelper.clamp(tx, -MAX_TILT, MAX_TILT) - tiltX) * 0.05f;
		tiltZ += (MathHelper.clamp(tz, -MAX_TILT, MAX_TILT) - tiltZ) * 0.05f;

		// --- движение с упором в блоки мира
		List<Box> boxes = hullBoxes(getX(), getY(), getZ(), shipYaw);
		Box all = getBoundingBox();
		double dx = vx, dy = vy, dz = vz;
		if (getY() + data.maxY + 1 + dy > getWorld().getTopY()) dy = Math.min(dy, 0);
		if (anyBlockCollision(all.stretch(dx, dy, dz).expand(0.01))) {
			dy = clipAxis(Direction.Axis.Y, dy, boxes);
			boxes = offsetAll(boxes, 0, dy, 0);
			dx = clipAxis(Direction.Axis.X, dx, boxes);
			boxes = offsetAll(boxes, dx, 0, 0);
			dz = clipAxis(Direction.Axis.Z, dz, boxes);
		}
		grounded = vy <= 0 && Math.abs(dy - vy) > 1.0E-5;
		if (Math.abs(dy - vy) > 1.0E-5) vy = 0;
		if (Math.abs(dx - vx) > 1.0E-5) vx = 0;
		if (Math.abs(dz - vz) > 1.0E-5) vz = 0;
		setVelocity(vx, vy, vz);
		setPosition(getX() + dx, getY() + dy, getZ() + dz);
		velocityDirty = true;
		ShipCollisions.carry(riders, oldPos, oldYaw, getPos(), shipYaw);

		if (getY() < getWorld().getBottomY() - 64) {
			discard();
			return;
		}

		// --- звук горелки
		if (heat > 0.05f && hasFuel && age % 40 == 0) {
			getWorld().playSound(null, getBlockPos(), SoundEvents.BLOCK_FIRE_AMBIENT, SoundCategory.NEUTRAL, 0.6f, 0.8f);
		}
		if (inDown && data.vents > 0 && age % 10 == 0) {
			getWorld().playSound(null, getBlockPos(), SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.NEUTRAL, 0.3f, 1.6f);
		}

		dataTracker.set(SHIP_YAW, shipYaw);
		dataTracker.set(TILT_X, round(tiltX));
		dataTracker.set(TILT_Z, round(tiltZ));
		dataTracker.set(HEAT, round(heat));
		dataTracker.set(THROTTLE, round(throttle));
		dataTracker.set(FUEL, (float) Math.ceil(fuel / 20f) * 20f);
		dataTracker.set(PROP_SPEED, propsOn ? round(0.25f + inForward * 0.75f) : 0f);
		dataTracker.set(VENTING, inDown && data.vents > 0);
		if (yawBefore != shipYaw) refreshBox();
	}

	private static float round(float v) {
		return Math.round(v * 200f) / 200f;
	}

	/** Повернуть вокруг центра тяжести; если корпус упрётся в блоки — не поворачивать. */
	private void tryRotate(float delta) {
		float newYaw = MathHelper.wrapDegrees(shipYaw + delta);
		Vec3d comOld = rotateXZ(data.centerOfMass.x, data.centerOfMass.z, shipYaw);
		Vec3d comNew = rotateXZ(data.centerOfMass.x, data.centerOfMass.z, newYaw);
		double nx = getX() + comOld.x - comNew.x;
		double nz = getZ() + comOld.z - comNew.z;
		for (Box b : hullBoxes(nx, getY(), nz, newYaw)) {
			if (anyBlockCollision(b.contract(0.05))) {
				yawRate = 0;
				return;
			}
		}
		shipYaw = newYaw;
		setPosition(nx, getY(), nz);
	}

	/** Обороты пропеллеров для рендера (−1..1). */
	public float getPropSpeed() {
		return dataTracker.get(PROP_SPEED);
	}

	public static boolean isPropeller(net.minecraft.block.BlockState s) {
		return s.getBlock() instanceof PropellerBlock;
	}
}
