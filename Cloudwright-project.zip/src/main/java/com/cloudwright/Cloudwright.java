package com.cloudwright;

import com.cloudwright.block.BurnerBlock;
import com.cloudwright.block.BurnerBlockEntity;
import com.cloudwright.block.EtheriteBlock;
import com.cloudwright.block.HelmBlock;
import com.cloudwright.block.PropellerBlock;
import com.cloudwright.block.SteamVentBlock;
import com.cloudwright.entity.ShipEntity;
import com.cloudwright.net.CloudwrightNetworking;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.ExperienceDroppingBlock;
import net.minecraft.block.MapColor;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.text.Text;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.intprovider.UniformIntProvider;
import net.minecraft.world.gen.GenerationStep;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class Cloudwright implements ModInitializer {
	public static final String MOD_ID = "cloudwright";
	public static final Logger LOGGER = LoggerFactory.getLogger("Cloudwright");

	public static Identifier id(String path) {
		return new Identifier(MOD_ID, path);
	}

	// ---------------------------------------------------------------- blocks
	public static final Block HELM = new HelmBlock(AbstractBlock.Settings.copy(Blocks.OAK_PLANKS).nonOpaque());
	public static final Map<DyeColor, Block> ENVELOPES = new EnumMap<>(DyeColor.class);
	public static final Block BURNER = new BurnerBlock(AbstractBlock.Settings.copy(Blocks.IRON_BLOCK).strength(3.5f)
			.luminance(s -> s.get(BurnerBlock.LIT) ? 13 : 0));
	public static final Block STEAM_VENT = new SteamVentBlock(AbstractBlock.Settings.copy(Blocks.COPPER_BLOCK).strength(2.5f).nonOpaque());
	public static final Block WOODEN_PROPELLER = new PropellerBlock(PropellerBlock.Kind.WOODEN,
			AbstractBlock.Settings.copy(Blocks.OAK_PLANKS).nonOpaque());
	public static final Block ANDESITE_PROPELLER = new PropellerBlock(PropellerBlock.Kind.ANDESITE,
			AbstractBlock.Settings.copy(Blocks.ANDESITE).strength(2.5f).nonOpaque());
	public static final Block SMART_PROPELLER = new PropellerBlock(PropellerBlock.Kind.SMART,
			AbstractBlock.Settings.copy(Blocks.GOLD_BLOCK).strength(2.5f).nonOpaque());
	public static final Block ETHERITE_ORE = new ExperienceDroppingBlock(AbstractBlock.Settings.copy(Blocks.STONE)
			.strength(3.0f, 3.0f).requiresTool().luminance(s -> 3), UniformIntProvider.create(2, 5));
	public static final Block ETHERITE_BLOCK = new EtheriteBlock(AbstractBlock.Settings.create().mapColor(MapColor.PURPLE)
			.strength(1.5f).sounds(BlockSoundGroup.AMETHYST_BLOCK).requiresTool().luminance(s -> 7));

	public static final Item ETHERITE_CRYSTAL = new Item(new Item.Settings());

	public static BlockEntityType<BurnerBlockEntity> BURNER_ENTITY;
	public static EntityType<ShipEntity> SHIP;

	/** Блоки, которые нельзя приклеить к судну (земля и камень вокруг). */
	public static final TagKey<Block> NOT_SHIP = TagKey.of(RegistryKeys.BLOCK, id("not_ship"));
	/** Места для пассажиров (сиденья Create и т.п.). */
	public static final TagKey<Block> SHIP_SEATS = TagKey.of(RegistryKeys.BLOCK, id("ship_seats"));

	private static final List<Item> GROUP_ITEMS = new ArrayList<>();

	private static void block(String name, Block block) {
		Registry.register(Registries.BLOCK, id(name), block);
		BlockItem item = Registry.register(Registries.ITEM, id(name), new BlockItem(block, new Item.Settings()));
		GROUP_ITEMS.add(item);
	}

	@Override
	public void onInitialize() {
		block("helm", HELM);
		for (DyeColor color : DyeColor.values()) {
			Block env = new Block(AbstractBlock.Settings.copy(Blocks.WHITE_WOOL).mapColor(color.getMapColor()));
			ENVELOPES.put(color, env);
			block(color.getName() + "_envelope", env);
		}
		block("burner", BURNER);
		block("steam_vent", STEAM_VENT);
		block("wooden_propeller", WOODEN_PROPELLER);
		block("andesite_propeller", ANDESITE_PROPELLER);
		block("smart_propeller", SMART_PROPELLER);
		block("etherite_ore", ETHERITE_ORE);
		block("etherite_block", ETHERITE_BLOCK);
		Registry.register(Registries.ITEM, id("etherite_crystal"), ETHERITE_CRYSTAL);
		GROUP_ITEMS.add(ETHERITE_CRYSTAL);

		BURNER_ENTITY = Registry.register(Registries.BLOCK_ENTITY_TYPE, id("burner"),
				FabricBlockEntityTypeBuilder.create(BurnerBlockEntity::new, BURNER).build());

		SHIP = Registry.register(Registries.ENTITY_TYPE, id("ship"),
				FabricEntityTypeBuilder.<ShipEntity>create(SpawnGroup.MISC, ShipEntity::new)
						.dimensions(EntityDimensions.changing(1f, 1f))
						.trackRangeChunks(12)
						.trackedUpdateRate(1)
						.forceTrackedVelocityUpdates(true)
						.disableSummon()
						.build());

		ItemGroup group = FabricItemGroup.builder()
				.icon(() -> new ItemStack(HELM))
				.displayName(Text.translatable("itemGroup.cloudwright"))
				.entries((ctx, entries) -> GROUP_ITEMS.forEach(entries::add))
				.build();
		Registry.register(Registries.ITEM_GROUP, id("main"), group);

		BiomeModifications.addFeature(BiomeSelectors.tag(BiomeTags.IS_MOUNTAIN), GenerationStep.Feature.UNDERGROUND_ORES,
				RegistryKey.of(RegistryKeys.PLACED_FEATURE, id("etherite_ore")));

		CloudwrightNetworking.registerServer();
		LOGGER.info("Cloudwright: гильдия небесных инженеров на месте");
	}
}
