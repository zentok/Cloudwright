package com.cloudwright.client;

import com.cloudwright.Cloudwright;
import com.cloudwright.block.BurnerBlock;
import com.cloudwright.block.PropellerBlock;
import com.cloudwright.entity.ShipData;
import com.cloudwright.entity.ShipEntity;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;

/** Рисует блоки судна каждый кадр: поворот, наклон вокруг центра тяжести, крутящиеся пропеллеры. */
public class ShipRenderer extends EntityRenderer<ShipEntity> {
	private final BlockRenderManager blocks;

	public ShipRenderer(EntityRendererFactory.Context ctx) {
		super(ctx);
		this.blocks = ctx.getBlockRenderManager();
		this.shadowRadius = 0f;
	}

	@Override
	public void render(ShipEntity ship, float entityYaw, float tickDelta, MatrixStack matrices,
					   VertexConsumerProvider consumers, int light) {
		ShipData data = ship.getData();
		if (data == null || data.isEmpty()) return;
		float yaw = MathHelper.lerp(tickDelta, ship.prevRenderYaw, ship.renderYaw);
		float tx = MathHelper.lerp(tickDelta, ship.prevRenderTiltX, ship.renderTiltX);
		float tz = MathHelper.lerp(tickDelta, ship.prevRenderTiltZ, ship.renderTiltZ);
		float spin = MathHelper.lerp(tickDelta, ship.prevSpin, ship.spin);
		boolean hot = ship.getHeat() > 0.02f && ship.getFuel() > 0;
		var world = MinecraftClient.getInstance().world;
		Vec3d com = data.centerOfMass;

		matrices.push();
		matrices.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(yaw));
		matrices.translate(com.x, com.y, com.z);
		matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(tx));
		matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(tz));
		matrices.translate(-com.x, -com.y, -com.z);

		double r = Math.toRadians(yaw);
		double c = Math.cos(r), s = Math.sin(r);
		BlockPos.Mutable lp = new BlockPos.Mutable();
		for (ShipData.ShipBlock b : data.visible) {
			BlockPos rel = b.rel();
			BlockState state = b.state();
			if (state.isOf(Cloudwright.BURNER)) state = state.with(BurnerBlock.LIT, hot);
			int blockLight = light;
			if (world != null) {
				lp.set(ship.getX() + rel.getX() * c - rel.getZ() * s, ship.getY() + rel.getY() + 0.5,
						ship.getZ() + rel.getX() * s + rel.getZ() * c);
				blockLight = WorldRenderer.getLightmapCoordinates(world, lp);
			}
			matrices.push();
			matrices.translate(rel.getX() - 0.5, rel.getY(), rel.getZ() - 0.5);
			if (state.getBlock() instanceof PropellerBlock prop) {
				Direction f = state.get(PropellerBlock.FACING);
				float speed = prop.kind == PropellerBlock.Kind.WOODEN ? 1.2f : prop.kind == PropellerBlock.Kind.ANDESITE ? 0.8f : 1.0f;
				matrices.translate(0.5, 0.5, 0.5);
				matrices.multiply(new Quaternionf().rotationAxis((float) Math.toRadians(spin * speed),
						f.getOffsetX(), f.getOffsetY(), f.getOffsetZ()));
				matrices.translate(-0.5, -0.5, -0.5);
			}
			blocks.renderBlockAsEntity(state, matrices, consumers, blockLight, OverlayTexture.DEFAULT_UV);
			matrices.pop();
		}
		matrices.pop();
	}

	@Override
	public Identifier getTexture(ShipEntity entity) {
		return PlayerScreenHandler.BLOCK_ATLAS_TEXTURE;
	}
}
