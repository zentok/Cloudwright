package com.cloudwright.mixin;

import net.minecraft.server.network.ServerPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Чтобы сервер не выкидывал за «полёт» игрока, который стоит на палубе летящего судна. */
@Mixin(ServerPlayNetworkHandler.class)
public interface ServerPlayNetworkHandlerAccessor {
	@Accessor("floatingTicks")
	void cloudwright$setFloatingTicks(int ticks);
}
